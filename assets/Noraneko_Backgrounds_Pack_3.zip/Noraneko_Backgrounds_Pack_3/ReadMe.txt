RULES

FOR GAMES:
-------------------------------------
-Give credit to "Noraneko Games".  
-Credit must be given in the in-game credits, a text file accompanying the game, or in the description where the game is downloaded.
-Assets cannot be resold on their own inside or outside of the game.
-Do not use to glorify pedophilia, homophobia, racism, or threats towards real people.
-NONE OF MY RELEASES ARE TO BE USED WITH AI IN ANY WAY(including but not limited to training, img2img, retouching, or paired with.)

FOR VTUBERS:
-------------------------------------
-Give credit to "Noraneko Games".
-Credit must be given in a description box on the streaming platform or in the video itself.
-Assets cannot be resold on their own inside or outside of the videos/vtubing.
-Do not use to glorify pedophilia, homophobia, racism, or threats towards real people.
-NONE OF MY RELEASES ARE TO BE USED WITH AI IN ANY WAY(including but not limited to training, img2img, retouching, or paired with.)

FOR ART:
-------------------------------------
-Give credit to "Noraneko Games".
-Credit must be given wherever the art is posted.
-Assets cannot be resold on their own inside or outside of the art.
-Do not use to glorify pedophilia, homophobia, racism, or threats towards real people.
-Cannot be used commercially.
-DO NOT USE FOR/IN NFTS!!!
-NONE OF MY RELEASES ARE TO BE USED WITH AI IN ANY WAY(including but not limited to training, img2img, retouching, or paired with.)


Q & A
-------------------------------------
Can I use this in 18+ content?
-Yes! Just please make sure that it doesn't positively promote things like pedophilia.

Can I use this in a game jam or contest?
-Yes! You have permission to use this in game jams or contests but it cannot be entered as a single piece (For example (but not limited to), you cannot enter any of the backgrounds into a background art contest because it is not yours.)

Can I use this commercially?
-For games, yes! It must still follow the rule that it cannot be sold alone. So it cannot be sold as an add-on for a visual novel engine for example. In short, if you make a game that uses it as a background but the user does not have to buy the background specifically to see it, that is fine!
By using the backgrounds commercially in your game, you are agreeing to let me know where the credit to my name is located if I ask.

Does tipping/donating mean I get to use it without credit?
-No! Giving credit to me is a very small act that I'm asking for from a large amount of work that I offer for free. Tips help me know that people like my work and go towards furthering my craft. Credit will ALWAYS be required.

Can I use this for an NFT?
-Absolutely not. DO NOT USE FOR/IN NFTS!!! It completely goes against several of my rules and my copyright is not abandoned.

Can I use this for any AI related uses?
-NO! I am firmly against AI art and using my works in, with, or for AI related purposes actually takes away from my livelihood as an artist. If you have any care at all for what I, and people like me, provide for free, please do not take advantage of our kindness like this.

Can I use this for merchandise/a piece of art I'm selling?
-In short, no.
Contact me on one of the locations listed on my caard (https://noranekogames.carrd.co/) to negotiate, but it will not be free to use for things like this.

Can I use this for my school project?
-If it is not being used commercially! Please make sure it follows everything mentioned above, though. It can't be the only thing your project consists of, for example, and I still require credit somewhere.

Can I use this for a visual novel engine?
-As long as it follows the rules in the Rules for Games section.

Are you making more backgrounds?
-Very slowly but I am working on them!

Can I modify the image?
-It must still follow the rules even if the image is changed, but you can modify it! Changing the colors, drawing over it in a new style (by hand, not with AI), adding characters, etc is absolutely fine.

Can I use it on Social Media?
-Please find a way to credit me if you do!

Do you use AI generation to create these?
-I'm proud to say that there was no AI generation used in creating these images. I use pictures I took personally on my phone camera or images from Creative Commons websites of real life media and then I draw/paint over them to create the images you will find in these downloads. If my lines seem weird, just know that I still struggle with areas in my art and it's just something I'm bad at.

-------------------------------------

Find more of my work at:
https://noranekogames.carrd.co/
Noranekokgames.itch.io

Not required, but I would love for you to link me to your project so I can view it!

Good luck with your project!